# DACATECH Cotizaciones (proyecto Android)

Proyecto Android con interfaz web local.

## Ajustes de importación incluidos
- Al leer líneas de productos desde PDF con texto, limpia el nombre comercial para separar atributos técnicos largos y mantiene la referencia detectada.
- Convierte 2 MP / 4 MP / 5 MP / 8 MP a megapíxeles en el nombre corto.
- Añade importación de archivos CSV exportados desde Excel y detecta columnas de nombre/descripción, referencia/modelo, cantidad/stock y precio/costo.
- Los productos importados siguen apareciendo para revisión antes de guardarse.

## Limitaciones de esta versión
- La lectura PDF usa el texto seleccionable del PDF; PDF escaneado como imagen requiere OCR y aún no está habilitado.
- Para Excel, exportar primero a CSV. Los archivos XLSX directos aún no se leen.
- La extracción del nombre se basa en reglas; siempre se muestra para revisión antes de guardar.

## Abrir
Abrir esta carpeta como proyecto en Android Studio y sincronizar Gradle.

## Versión 1.8 — conexión a PocketBase
- Servidor: https://baseapp.patatas.space (colecciones `users` y `datos`).
- Inicio de sesión y registro con correo + contraseña (colección `users`).
- Todos los datos (cotizaciones, clientes, productos, gastos, ingresos) se sincronizan en la colección `datos`, un registro por usuario. Sigue funcionando sin internet y sincroniza al reconectar/guardar.
- Se agregó el permiso INTERNET al AndroidManifest.
